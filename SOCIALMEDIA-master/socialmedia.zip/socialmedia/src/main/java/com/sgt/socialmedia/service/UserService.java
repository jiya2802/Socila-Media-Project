package com.sgt.socialmedia.service;

import com.sgt.socialmedia.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;

    public ResponseEntity<Map<String, String>> insertUser(Map<String,Object> body){
        String user_name = (String) body.get("user_name");
        String email = (String) body.get("email");
        String contact = (String) body.get("contact");
        String password = (String) body.get("password");

        int noOfRows = userRepository.insertUser(user_name,email,contact , password);


        if(noOfRows>0){
            return ResponseEntity.ok(Map.of("status" , "successfully inserted user"));
        }
        return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(Map.of("status" , "user insertion failed"));
    }
    public Map<String ,Object> loginUser(Map<String,Object> body){
        String email = (String)body.get("email");
        String password = (String)body.get("password");
        return userRepository.loginUser(email,password);
    }
}
